
public class SieveOfEratosthenes {
	
	public static long primes(boolean[] nums) {
		long time = System.currentTimeMillis();
		
		int num = 2;
		while(num*num<nums.length) {
			for(int q = num+num; q<nums.length; q+=num) {
				nums[q]=true;
			}
			for(int q = num+1; q<nums.length; q++) {
				if(!nums[q]) {
					num = q;
					break;
				}
			}
		}
		return System.currentTimeMillis()-time;
	}
}
