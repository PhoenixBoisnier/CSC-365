import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Pathfinder {
	
	public static void main(String[] args) {
		
		int nodes = 0;
		//TODO change file here
		File f = new File("list2.txt");
		Scanner scone = new Scanner("");
		scone.close();
		boolean notFound = false;
		try {
			scone = new Scanner(f);
		} catch (FileNotFoundException e1) {
			System.out.println("404");
			notFound = true;
			e1.printStackTrace();
		}
		while(scone.hasNextLine()) {
			scone.nextLine();
			nodes++;
		}
		
		/**
		 * This adjacency matrix is filled as follows:
		 * 	rows = node number
		 * 	adjMat[q][q] = duration of task q
		 * 	adjMat[q][w] = path to w exists or not
		 * 		where w < 0 is false and w >= 0 is 
		 * 		true for all q != w
		 */
		int[][] adjMat = new int[nodes][nodes];
		for(int q = 0; q<nodes; q++) {
			for(int w = 0; w<nodes; w++) {
				adjMat[q][w] = -1;
			}
		}
		
		//This section reads in the node info.
		ArrayList<Node> nodeList = new ArrayList<>();
		scone.close();
		try {
			scone = new Scanner(f);
		} catch (FileNotFoundException e1) {
			System.out.println("404");
			notFound = true;
			e1.printStackTrace();
		}
		
		while(!notFound&&scone.hasNext()) {
			Node n = parseInput(scone.nextLine());
			adjMat[n.num][n.num] = n.dur;
			for(int q = 0; q<n.req.size(); q++) {
				adjMat[n.num][n.req.get(q)] = 1;
			}
			nodeList.add(n);
		}
		scone.close();
		
		//This section calculates where to start.
		ArrayList<Process> processes = new ArrayList<>();
		ArrayList<Node> availableTasks = new ArrayList<>();
		updateAvailability(adjMat,availableTasks);
		
		//This calculates our processes.
		int time = 0;
		while(true) {
			
			//Assigns all available tasks to a processor.
			for(Node task : availableTasks) {
				boolean assigned = false;
				//Finds an available process.
				for(Process p : processes) {
					if(!p.isFull()) {
						assigned = p.taskProcess(task, time);
						break;
					}
				}
				//If none were available, a new processor is made.
				if(!assigned) {
					Process p = new Process();
					p.taskProcess(task, time);
					processes.add(p);
				}
			}
			availableTasks = new ArrayList<>();
			
			//Now that all available tasks are assigned, they get worked on.
			for(Process p : processes) {
				Node n = p.taskAdvance(time);
				//If the task is completed, the matrix is updated. 
				if(n!=null) {
					for(Integer i : n.req) {
						adjMat[n.num][i] = -1;
					}
				}
				//And if a new task becomes available, is is added to the 
				//availability list.
				updateAvailability(adjMat,availableTasks);
			}
			time++;
			
			//Now we check to see if we're done.
			if(availableTasks.size()==0) {
				//If there are no next tasks, we make sure all processes are done.
				boolean breaker = true;
				for(Process p : processes) {
					//If even one process is still going, we do not break.
					if(p.isFull()) {
						breaker = false;
						break;
					}
				}
				//This will break the while(true) loop.
				if(breaker) {
					break;
				}
			}
		}
		for(Node n : nodeList) {
			System.out.println(n);
		}
	}
	
	/**
	 * Parses a node object from the adjacency matrix.
	 * @param index
	 * @param adj
	 * @return
	 */
	public static Node parseNode(int index, int[][] adj) {
		Node n = new Node();
		n.num = index;
		n.dur = adj[index][index];
		ArrayList<Integer> children = new ArrayList<>();
		for(int q = 0; q<adj.length; q++) {
			if(adj[index][q]!=-1) {
				children.add(q);
			}
		}
		n.req = children;
		return n;
	}
	
	/**
	 * Updates the available task list.
	 * @param adjMat
	 * @param availableTasks
	 */
	public static void updateAvailability(int[][] adjMat, 
			ArrayList<Node> availableTasks) {
		for(int w = 0; w<adjMat.length; w++) {
			boolean hasChildren = false;
			for(int q = 0; q<adjMat.length; q++) {
				if(q!=w && adjMat[q][w]!=-1) {
					hasChildren = true;
					break;
				}
			}
			if(!hasChildren) {
				if(adjMat[w][w] != -1) {
					availableTasks.add(parseNode(w,adjMat));
					adjMat[w][w] = -1;
				}
			}
		}
	}
	
	/**
	 * Self explanatory.
	 * @param adj
	 */
	public static void printMat(int[][] adj) {
		for(int q = 0; q<adj.length; q++) {
			for(int w = 0; w<adj.length; w++) {
				if(adj[q][w]==1) {
					System.out.print(" "+adj[q][w]+" ");
				}
				else System.out.print(adj[q][w]+" ");
			}
			System.out.println();
		}
	}
	
	/**
	 * Parses a node from from a string in format <num> <dur>( <child>)*
	 * @param nodeData
	 * @return
	 */
	public static Node parseInput(String nodeData) {
		Node n = new Node();
		
		n.num = Integer.parseInt(nodeData.substring(0, nodeData.indexOf(' ')));
		nodeData = nodeData.substring(nodeData.indexOf(' ')+1);
		if(nodeData.indexOf(' ')==-1) {
			n.dur = (int)(Double.parseDouble(nodeData));
		}
		else {
			n.dur = (int)(Double.parseDouble(
					nodeData.substring(0, nodeData.indexOf(' '))));
		}
		ArrayList<Integer> children = new ArrayList<>();
		if(nodeData.indexOf(' ')!=-1) {
			nodeData = nodeData.substring(nodeData.indexOf(' ')+1);
			while(nodeData.indexOf(' ')!=-1) {
				children.add(
						Integer.parseInt(
								nodeData.substring(0,nodeData.indexOf(' '))));
				nodeData = nodeData.substring(nodeData.indexOf(' ')+1);
			}
			children.add(Integer.parseInt(nodeData));
		}
		n.req = children;

		return n;
	}

}
