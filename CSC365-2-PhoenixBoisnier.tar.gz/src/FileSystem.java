import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * 
 * @author phoenix
 *
 *
 *
 *
 *
 */
public class FileSystem {
	
	static RBTree patientsIndex = new RBTree();
	static ArrayList<Patient> patients = new ArrayList<>();
	static Scanner scone = new Scanner(System.in);
	static PatientStudyMaker generator = new PatientStudyMaker();
	static String filePath = System.getProperty("user.home")+"/CSC365-2";
	static File results = null;
	static boolean runnable = true;
	
	public static void main(String[] args) {
		
		boolean running = true;
		
		while(running) {
			
			setup();
			
			while(runnable) {
				System.out.println("Find patient records for?");
				String inp = scone.nextLine();
				if(inp.equalsIgnoreCase("exit")) {
					running = false;
					break;
				}
				else if(inp.equalsIgnoreCase("ploop")) {
					while(!inp.equalsIgnoreCase("stop")) {
						inp = scone.nextLine();
						Patient p = patients.get(
								patientsIndex.get(Integer.parseInt(inp)));
						inp = scone.nextLine();
						Study s = p.getStudy(Double.parseDouble(inp));
						ArrayList<Integer> imgs = s.getImages();
						for(int q = 0; q<imgs.size(); q++) {
							System.out.println(imgs.get(q));
						}
					}
				}
				else if(inp.equalsIgnoreCase("setup")) {
					setup();
				}
				else if(inp.equalsIgnoreCase("print")) {
					for(Patient p : patients) {
						System.out.println(p.patNum);
					}
				}
				else if(inp.equalsIgnoreCase("size")) {
					System.out.println(patientsIndex.getSize());
				}
				else if(inp.equalsIgnoreCase("help")) {
					System.out.println("Type exit to quit, type setup to generate "
							+ "new patients.");
				}
				else {
					int pID;
					try{
						pID = Integer.parseInt(inp);
					} catch(NumberFormatException e) { 
						System.out.println("Invalid ID.");
						pID = 0;
					}
					Patient p = FileSystem.getPatient(pID);
					if(p==null) {
						System.out.println("Patient not found.");
					}
					else {
						System.out.println("What time (mmddyy.hhmmss or ALL)?");
						String s = scone.nextLine();
						if(s.equalsIgnoreCase("all")) {
							ArrayList<Study> stud = p.studies;
							for(Study st : stud) {
								System.out.println("Study: "+st.getTime());
								ArrayList<Integer> images = st.getImages();
								for(int i : images) {
									System.out.println("\t"+i);
								}
							}
						}
						else {
							try{
								double time = Double.parseDouble(s);
								ArrayList<Integer> images = 
										p.getStudy(time).getImages();
								if(images==null) {
									System.out.println("Study not found.");
								}
								else {
									System.out.println("Images at study: "+time);
									for(int i : images) {
										System.out.println("\t"+i);
									}
								}
							} catch (NumberFormatException e) {
								System.out.println("Improper input format.");
							} catch (ArrayIndexOutOfBoundsException e) {
								System.out.println("Index not found.");
							}
						}
					}
				}
			}
			
			System.out.println("Goodbye.");
			
		}	
	}
	
	/**
	 * Controls the settings.
	 */
	public static void setup() {
		System.out.println("Would you like to restrict quantity? (y/n)");
		if(scone.nextLine().equalsIgnoreCase("n")) {
			System.out.println("Are you sure? This can cause stack overflow. (y/n)");
			if(scone.nextLine().equalsIgnoreCase("y")) {
				generator.toggleRest();
			}
		}
		
		String scanning = "";
		System.out.println("How many entries?");
		scanning = scone.nextLine();
		results = generator.writeIt(Integer.parseInt(scanning), filePath);
		
		try {
			Scanner fscone = new Scanner(results);
			FileSystem.readFile(fscone, patientsIndex, patients);
		} catch (FileNotFoundException e) {
			System.out.println("Error encountered while loding file.");
			runnable = false;
			e.printStackTrace();
		}
	}

	/**
	 * Builds the database.
	 * @param fScone
	 * @param patients
	 * @param patList
	 */
	public static void readFile(Scanner fScone, RBTree patients,
			ArrayList<Patient> patList) {

		System.out.println("Building database...");
		
		while(fScone.hasNextLine()) {
			String process = fScone.nextLine();
			if(process.length()<27) {
				break;
			}
			String[] hold = FileSystem.processInput(process);
			FileSystem.addPatient(
					Integer.parseInt(hold[0]),
					Integer.parseInt(hold[1]),
					Integer.parseInt(hold[2]),
					Integer.parseInt(hold[3]));
		}
		
		System.out.println("Database completed.");
		
	}
	
	/**
	 * Parses the input strings s follows:
	 * 	first 7 digits are patient number
	 * 	next 12 digits are time in mmddyyhhmmss format
	 * 	last 7 digits are the image file name prefix
	 * @param input
	 * @return
	 */
	public static String[] processInput(String input) {
		
		String[] val = new String[4];
		
		val[0] = input.substring(0, 7);
		val[1] = input.substring(7, 13);
		val[2] = input.substring(13, input.indexOf('.'));
		val[3] = input.substring(input.indexOf('.')+1, input.length());
		
		return val;
		
	}
	
	/**
	 * Adds the patient to the list with the study time and info.
	 * @param p
	 */
	public static void addPatient(int p, int mmddyy, int hhmmss, int image) {
		int index = patientsIndex.get(p);
		if(index == -1) {
			Patient pat = new Patient(p);
			pat.addStudyInfo(mmddyy, hhmmss, image);
			patients.add(pat);
			patientsIndex.add(pat.patNum, patients.size()-1);
		}
		else {
			patients.get(index).addStudyInfo(mmddyy, hhmmss, image);
		}
	}
	
	/**
	 * Retrieves the patient ID.
	 * @param pID
	 * @return
	 */
	public static Patient getPatient(int pID) {
		int index = patientsIndex.get(pID);
		if(index != -1) {
			return patients.get(index);
		}
		else return null;
	}
	
	/**
	 * Gets the studies at time mmddyy.hhmmss.
	 * @param p
	 * @param time
	 * @return
	 */
	public static ArrayList<Integer> getStudies(Patient p, double time) {
		int index = p.studiesIndex.get(time);
		if(index != -1) {
			return p.studies.get(index).getImages();
		}
		else return null;
	}
	
}


