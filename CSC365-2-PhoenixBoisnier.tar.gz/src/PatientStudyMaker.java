import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;

/**
 * 
 * @author phoenix
 *
 */
public class PatientStudyMaker {

	private boolean restricted = true;
	
	/**
	 * 
	 * @param entries
	 * @param path
	 */
	public File writeIt(int entries, String path) {
		
		File dir = new File(path);
		File results = new File(path+"/Patients.txt");
		Writer write = null;
		//The results file should only not exist when the program is first run
		//on a new machine.
		if(!results.exists()) {
			System.out.println("File not found.");
			dir.mkdirs();
			try {
				results.createNewFile();
			} catch (IOException i) {
				i.printStackTrace();
			}
		}
		
		//This makes the writer and writes to file.
		try {
			write = new BufferedWriter(new FileWriter(results));
			System.out.println("Save-To file found...");
			System.out.println("Saving results...");
			for(int q = 0; q<entries; q++) {
				for(String s : this.makeIt()) {
					write.write(s+"\n");
					write.flush();
				}
			}
		} catch (IOException i) {
			i.printStackTrace();
			System.out.println("Save-To file not found.");
		}
		
		return results;
	}
	
	/**
	 * Makes info for a given patient.
	 * @return
	 */
	public ArrayList<String> makeIt() {
		String pVal = "";
		String date = "";
		String time = "";
		ArrayList<String> allPatient = new ArrayList<>();
		//this makes the patient number
		pVal = this.makePati();
		int studies = (int)(Math.random()*10+1);
		if(restricted) {
			studies = (int)(Math.random()*2+1);
		}
		//this determines how many studies(mmddyy) the patient has
		for(int w = 0; w<studies; w++) {
			date = this.makeDate();
			int studs = (int)(Math.random()*3+1);
			if(restricted) {
				studs = 1;
			}
			//this determines how many photo shoots (hhmmss) are per study
			for(int e = 0; e<studs; e++) {
				time = this.makeTime();
				int imgS = (int)(Math.random()*256+1);
				if(restricted) {
					imgS = (int)(Math.random()*10+1);
				}
				//this determines how many photos per shoot
				int imagStart = (int)(Math.random()*8999999+1000000);
				for(int r = 0; r<imgS; r++) {
					//this adds it all to the arraylist
					allPatient.add(pVal+date+time+"."+(imagStart++));
				}
			}
		}
		
		
		return allPatient;
	}
	
	/**
	 * Makes a random patient ID.
	 * @return
	 */
	private String makePati() {
		String pati = "";
		for(int q = 0; q<7; q++) {
			int patiD = (int)(Math.random()*10);
			pati+=patiD;
		}
		while(pati.length()<7) {
			pati = "0"+pati;
		}
		return pati;
	}
	
	/**
	 * Makes a random date.
	 * @return
	 */
	private String makeDate() {
		String date = "";
		int m1 = (int)(Math.random()*12+1);
		if(m1<10) {
			date+="0";
		}
		date+=m1;
		int d1 = (int)(Math.random()*31+1);
		if(d1<10) {
			date+="0";
		}
		date+=d1;
		int y = (int)(Math.random()*100);
		if(y==0) {
			date+="00";
		}
		if(y<10&&y!=0) {
			date+="0";
		}
		date+=(""+y);
		return date;
	}
	
	/**
	 * Makes a random time.
	 * @return
	 */
	private String makeTime() {
		String time = "";
		int h1 = (int)(Math.random()*3);
		int h2 = (int)(Math.random()*10);
		if(h1==2) {
			h2%=4;
		}
		time+=h1;
		time+=h2;
		int m1 = (int)(Math.random()*6);
		int m2 = (int)(Math.random()*10);
		int s1 = (int)(Math.random()*6);
		int s2 = (int)(Math.random()*10);
		time+=m1;
		time+=m2;
		time+=s1;
		time+=s2;
		return time;
	}
	
	/**
	 * Toggles restricted image file quantity.
	 */
	public void toggleRest() {
		if(restricted) {
			restricted = false;
		}
		else {
			restricted = true;
		}
	}
	
}
