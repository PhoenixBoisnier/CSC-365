
public class Process {
	
	private static int pCount = 0;
	private int processNum;
	Node n = null;
	private int completedIn; 
	public Process() {
		pCount++;
		processNum = pCount;
	}
	
	/**
	 * 
	 * @return true iff n is not null.
	 */
	public boolean isFull() {
		return (n!=null);
	}
	
	/**
	 * Tasks the processor with a new task.
	 * @param next The next task to be completed.
	 * @param time The time the task is started at.
	 * @return true iff task is assigned.
	 */
	public boolean taskProcess(Node next, int time) {
		if(this.isFull()) {
			return false;
		}
		else {
			n = next;
			completedIn = n.dur;
			System.out.println("Processor "+processNum+" assigned task "+n.num+
					" at time "+time+".");
			return true;
		}
	}
	
	/**
	 * Advances the time to completion (0) of the process's task (node). 
	 * @param time The time the task is finished at.
	 * @return If the task is completed, its children are returned.
	 */
	public Node taskAdvance(int time) {
		Node retVal = null;
		completedIn--;
		if(completedIn==0) {
			System.out.println("Processor "+processNum+" completed task "+n.num+
					" at time "+time+".");
			retVal = n;
			n = null;
		}
		return retVal;
	}
}
