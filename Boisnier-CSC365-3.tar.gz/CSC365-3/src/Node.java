import java.util.ArrayList;

public class Node {
	
		int num;
		int dur;
		ArrayList<Integer> req = new ArrayList<>();
		
		public String toString() {
			String returns = "Node "+num+" for "+dur+"\n";
			returns+="\t"+req.toString();
			return returns;
		}
}