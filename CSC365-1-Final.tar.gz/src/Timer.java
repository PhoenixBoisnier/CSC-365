
public class Timer {
	
	private long begin;
	private long end;
	private long diff;
	
	public void start() {
		begin = System.currentTimeMillis();
	}
	public long stop() {
		end = System.currentTimeMillis();
		return end - begin;
	}
	public long getDiff() {
		return diff;
	}
	public void reset() {
		begin = 0;
		end = 0;
		diff = 0;
	}

}
