import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class SpeedTest {
	
	public static void main(String[] args) {
		
		Scanner scone = new Scanner(System.in);
		String input = "";
		Timer erT = new Timer();
		Timer suT = new Timer();
		
		//Actual speed test portion
		System.out.println("Enter q at any time to quit.");
		while(!input.equalsIgnoreCase("q")) {
			System.out.println("Find primes up to value?");
			input = scone.nextLine();
			if(input.equalsIgnoreCase("q")) {
				break;
			}
			try {
				int size = Integer.parseInt(input);
				boolean[] nums = new boolean[size];
				long eTime = SieveOfEratosthenes.primes(nums);
				String eSults = printsPrimes(nums,false,erT);
				System.out.println(eSults);
				nums = new boolean[size];
				long sTime = SieveOfSundaram.primes(nums);
				String sSults = printsPrimes(nums,true,suT);
				System.out.println(sSults);
				System.out.println("Eratosthenes time: "+(eTime+erT.getDiff()));
				System.out.println("Sudaram time: "+(sTime+suT.getDiff()));
				saveFile(size, eTime, sTime, eSults, sSults, suT, erT);
			} catch (NumberFormatException e) {
				System.out.println("Invalid entry.");
			}
		}
		System.out.println("Goodbye.");
		scone.close();
	}
	
	/**
	 * This method will save the data from tests to a .txt file in the home
	 * directory in a folder.
	 * @param size
	 * @param eTime
	 * @param sTime
	 */
	private static void saveFile(int size, long eTime, long sTime, String e, 
			String s, Timer suT, Timer erT) {
		
		BufferedWriter write = null;
		String path = System.getProperty("user.home")+"/CSC365-1";
		File dir = new File(path);
		File results = new File(dir.getPath()+"/TestResults.txt");
		//The results file should only not exist when the program is first run
		//on a new machine.
		if(!results.exists()) {
			System.out.println("File not found.");
			dir.mkdirs();
			try {
				results.createNewFile();
			} catch (IOException i) {
				i.printStackTrace();
			}
		}
		Scanner scone2 = null;
		try {
			scone2 = new Scanner(results);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		//This saves the previous data
		String prevRes = "";
		while(scone2.hasNextLine()) {
			prevRes+=scone2.nextLine()+"\n";
		}
		
		//This makes the writer
		try {
			write = new BufferedWriter(new FileWriter(results));
			System.out.println("Save-To file found...");
		} catch (IOException i) {
			i.printStackTrace();
			System.out.println("Save-To file not found.");
		}
		
		//Writes info to file
		try {
			System.out.println("Saving results...");
			write.write(prevRes);
			write.write("-------Test on size: "+size+"-------\n");
			write.write("Eratosthenes time: "+(eTime+erT.getDiff())
					+", Sundaram time: "+(sTime+suT.getDiff())+
					"\n\n");
			write.write(e);
			write.write(s);
			write.write("\n\n");
			write.flush();
		} catch (IOException i) {
			i.printStackTrace();
			System.out.println("Failed to save.");
		}	
	}
	/**
	 * This method prints the results to the console.
	 * @param nums
	 * @param sundaram
	 */
	private static String printsPrimes(boolean[] nums, boolean sundaram, Timer t) {
		String result = "";
		if(sundaram) {
			t.start();
			result = "Sundaram primes: \n";
			int lc = 1;
			result+=(2+" ");
			for(int q = 1; q<nums.length/2; q++) {
				if(!nums[q]) {
					result+=((2*q+1)+" ");
					lc++;
				}
				if(lc==9) {
					lc = 0;
					result+="\n";
				}
			}
			result+="\n";
			t.stop();
		}
		else {
			t.start();
			result = "Eratosthenes primes: \n";
			int lc = 0;
			for(int q = 2; q<nums.length; q++) {
				if(!nums[q]) {
					result+=(q+" ");
					lc++;
				}
				if(lc==9) {
					lc = 0;
					result+="\n";
				}
			}
			result+="\n";
			t.stop();
		}
		return result;
	}
}

