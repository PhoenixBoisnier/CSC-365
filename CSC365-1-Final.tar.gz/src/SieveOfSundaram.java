
public class SieveOfSundaram {

	public static long primes(boolean[] nums) {
		long time = System.currentTimeMillis();
		int m = nums.length/2;
		for(int i = 1; i<m; i++) {
			for(int j = i; j<=((m-i)/(2*i+1)); j++) {
				nums[(i+j+2*i*j)] = true;
			}
		}
		long timeD = System.currentTimeMillis();
		return timeD-time;
	}
}
