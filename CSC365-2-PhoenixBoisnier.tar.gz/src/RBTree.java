
public class RBTree {
	
	private int size = 0;
	private Node root;
	
	private class Node {
		
		boolean black = false;
		double value = -1;
		int index = -1;
		Node left = null;
		Node right = null;
		Node parent = null;
		
		public void swapColor() {
			if(black) {
				black = false;
			}
			else black = true;
		}
		
	}
	
	/**
	 * Adds the value and index at the appropriate location in the tree.
	 * @param inputValue
	 * @param inputIndex
	 */
	public void add(double inputValue, int inputIndex) {
		
		if(get(inputValue)==-1) {
			if(root==null) {
				Node n = new Node();
				n.index = inputIndex;
				n.value = inputValue;
				root = n;
				size++;
				root.swapColor();
			}
			else {
				Node n = root;
				Node np = n.parent;
				while(n!=null) {
					if(n.value<inputValue) {
						np = n;
						n = n.right;
						if(n!=null) {
							n.parent = np;
						}
					}
					else {
						np = n;
						n = n.left;
						if(n!=null) {
							n.parent = np;
						}
					}
				}
				n = new Node();
				n.parent = np;
				n.value = inputValue;
				n.index = inputIndex;
				if(np.value<inputValue) {
					np.right = n;
				}
				else {
					np.left = n;
				}
				size++;
				this.recolor(n);
			}
		}
	}
	
	/**
	 * Returns -1 if value not present, else returns index.
	 * @param inputValue
	 * @return
	 */
	public int get(double inputValue) {
		Node res = getNode(inputValue, root);
		if(res==null) {
			return -1;
		}
		else {
			return res.index;
		}
	}
	
	/**
	 * Private traversal method to get index at the value specified.
	 * @param inputValue
	 * @return
	 */
	private Node getNode(double inputValue, Node n) {
		if(n==null) {
			return null;
		}
		else {
			if(n.value==inputValue) {
				return n;
			}
			else if(n.value<inputValue) {
				return getNode(inputValue,n.right);
			}
			else {
				return getNode(inputValue,n.left);
			}
		}
	}
	
	/**
	 * 
	 * @param n
	 */
	private void recolor(Node n) {
		if(n==root) {
			if(!n.black) {
				n.swapColor();
			}
		}
		else {
			if(n.parent.black) {
				//do nothing
			}
			else {
				if(n.parent==root) {
					if(!n.parent.black) {
						n.parent.swapColor();
					}
				}
				else if(n.parent.left!=null) {
					Node uncl = null;
					Node nPar = n.parent;
					Node gPar = nPar.parent;
					if(nPar==gPar.left) {
						uncl = gPar.right;
					}
					else {
						uncl = gPar.left;
					}
					if(uncl==null||uncl.black) {
						unclBlackLeft(n);
					}
					else {
						if(!n.parent.black) {
							n.swapColor();
						}
						if(gPar.black) {
							gPar.swapColor();
						}
						recolor(gPar);
					}
				}
				else {
					if(n.parent.right!=null) {
						Node uncl = null;
						Node nPar = n.parent;
						Node gPar = nPar.parent;
						if(nPar==gPar.right) {
							uncl = gPar.right;
						}
						else {
							uncl = gPar.right;
						}
						if(uncl==null||uncl.black) {
							unclBlackRight(n);
						}
						else {
							if(!n.parent.black) {
								n.swapColor();
							}
							if(gPar.black) {
								gPar.swapColor();
							}
							recolor(gPar);
						}
					}
				}
			}
		}
	}
	
	/**
	 * 
	 * @param n
	 */
	private void unclBlackLeft(Node n) {
		if(n==n.parent.left) {
			if(n.parent.parent.black) {
				n.parent.parent.swapColor();
			}
			if(n.black) {
				n.swapColor();
			}
			Node gPar = n.parent.parent;
			rotateLeft(n.parent);
			rotateRight(gPar);
		}
		else {
			if(!n.parent.black) {
				n.parent.swapColor();
			}
			if(n.parent.parent.black) {
				n.parent.parent.swapColor();
			}
			rotateRight(n.parent.parent);
		}
	}
	
	/**
	 * 
	 * @param n
	 */
	private void unclBlackRight(Node n) {
		if(n==n.parent.right) {
			if(n.parent.parent.black) {
				n.parent.parent.swapColor();
			}
			if(n.black) {
				n.swapColor();
			}
			Node gPar = n.parent.parent;
			rotateRight(n.parent);
			rotateLeft(gPar);
		}
		else {
			if(!n.parent.black) {
				n.parent.swapColor();
			}
			if(n.parent.parent.black) {
				n.parent.parent.swapColor();
			}
			rotateLeft(n.parent.parent);
		}
	}
	
	/**
	 * 
	 * @param rot
	 */
	private void rotateLeft(Node rotate) {
		
	/*	Node nPar = rotate;
		Node nParR = nPar.right;
		Node gPar = nPar.parent;
		Node qPar = null;
		boolean qParL = false;
		if(gPar!=null&&gPar.parent==null) {
			nPar.parent = null;
			nParR = nPar.right;
			nPar.right = gPar;
			gPar.parent = nPar;
			gPar.left = nParR;
			if(nParR!=null) {
				nParR = gPar;
			}
			root = nPar;
		}
		else if(gPar!=null){
			qPar = gPar.parent;
			if(qPar.left == gPar) {
				qParL = true;
			}
			if(qParL) {
				qPar.left = nPar;
				nPar.parent = qPar;
				gPar.parent = nPar;
				nPar.right = gPar;
				gPar.left = nParR;
				if(nParR!=null) {
					nParR.parent = gPar;
				}
			}
		}*/
		
	/*	Node nPar = rotate;
		Node gPar = nPar.parent;
		if(gPar.parent==null) {
			gPar.left = nPar.right;
			if(nPar.right!=null) {
				nPar.right.parent = gPar;
			}
			nPar.right = gPar;
			gPar.parent = nPar;
			nPar.parent = null;
			root = nPar;
		}
		else {
			Node qPar = gPar.parent;
			boolean qParL = true;
			if(gPar==qPar.right) {
				qParL = false;
			}
			gPar.left = nPar.right;
			if(nPar.right!=null) {
				nPar.right.parent = gPar;
			}
			nPar.right = gPar;
			gPar.parent = nPar;
			nPar.parent = qPar;
			if(qParL) {
				qPar.left = nPar;
			}
			else {
				qPar.right = nPar;
			}
		}*/
	}
	
	/**
	 * 
	 * @param rot
	 */
	private void rotateRight(Node rotate) {
	
	/*	Node nPar = rotate;
		Node nParL = nPar.left;
		Node gPar = nPar.parent;
		Node qPar = null;
		boolean qParR = false;
		if(gPar!=null&&gPar.parent==null) {
			nPar.parent = null;
			nParL = nPar.left;
			nPar.left = gPar;
			gPar.parent = nPar;
			gPar.right = nParL;
			if(nParL!=null) {
				nParL = gPar;
			}
			root = nPar;
		}
		else if(gPar!=null){
			qPar = gPar.parent;
			if(qPar.right == gPar) {
				qParR = true;
			}
			if(qParR) {
				qPar.right = nPar;
				nPar.parent = qPar;
				gPar.parent = nPar;
				nPar.left = gPar;
				gPar.right = nParL;
				if(nParL!=null) {
					nParL.parent = gPar;
				}
			}
		}*/
		
	/*	Node nPar = rotate;
		Node gPar = nPar.parent;
		if(gPar.parent==null) {
			gPar.right = nPar.left;
			if(nPar.left!=null) {
				nPar.left.parent = gPar;
			}
			nPar.left = gPar;
			gPar.parent = nPar;
			nPar.parent = null;
			root = nPar;
		}
		else {
			Node qPar = gPar.parent;
			boolean qParL = true;
			if(gPar==qPar.left) {
				qParL = false;
			}
			gPar.right = nPar.left;
			if(nPar.left!=null) {
				nPar.left.parent = gPar;
			}
			nPar.left = gPar;
			gPar.parent = nPar;
			nPar.parent = qPar;
			if(qParL) {
				qPar.right = nPar;
			}
			else {
				qPar.left = nPar;
			}
		}*/
	}

	public int getSize() {
		return size;
	}
	
}


