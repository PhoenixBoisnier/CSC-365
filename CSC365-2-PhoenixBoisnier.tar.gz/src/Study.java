import java.util.ArrayList;

/**
 * 
 * @author phoenix
 * 
 * Holds image files of type int and length 7.
 * Named with 12 digit time in format mmddyyhhmmss.
 *
 */
public class Study {
	
	private double studyTime;
	private ArrayList<Integer> imageFiles = new ArrayList<>();
	
	/**
	 * Creates a new study with value time mmddyyhhmmss
	 * @param time
	 */
	public Study(double time) {
		studyTime = time;
	}
	
	/**
	 * Returns the "name" of the study as its time in mmddyy
	 * @return
	 */
	public double getTime() {
		return studyTime;
	}
	
	/**
	 * Adds image to the study.
	 * @param image
	 */
	public void addImage(int image) {
		imageFiles.add(image);
	}
	
	/**
	 * Returns the list of image files.
	 * @return
	 */
	public ArrayList<Integer> getImages(){
		return imageFiles;
	}

}
