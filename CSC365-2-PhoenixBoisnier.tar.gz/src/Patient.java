import java.util.ArrayList;

/**
 * 
 * @author phoenix
 *
 *
 * Patients hold information on their studies conducted and are
 * identified by their ID number in format int xxxxxxx.
 *
 */
public class Patient {

	RBTree studiesIndex = new RBTree();
	ArrayList<Study> studies = new ArrayList<>();
	int patNum;
	
	/**
	 * Creates a patient with ID number xxxxxxx.
	 * @param i
	 */
	public Patient(int i) {
		patNum = i;
	}
	
	/**
	 * Adds a study and image to the patient if the study is not already present.
	 * @param time
	 * @param image
	 */
	public void addStudyInfo(int mmddyy, int hhmmss, int image) {
		
		double time = mmddyy;
		double hold = ((double)(hhmmss)) / 1000000;
		time += hold;
		int index = studiesIndex.get(time);
		if(index == -1){
			studiesIndex.add(time, studies.size());
			Study s = new Study(time);
			s.getImages().add(image);
			studies.add(s);
		}
		else {
			studies.get(index).getImages().add(image);
		}
		
	}
	
	/**
	 * Returns the study of specified time mmddyy.
	 * @param time
	 * @return Study
	 */
	public Study getStudy(double time) {
		return studies.get(studiesIndex.get(time));
	}
}
